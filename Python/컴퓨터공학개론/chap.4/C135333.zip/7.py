#7번 문제, C135333, 임원재

for i in range(1, 51):
    print("%d\t%d\t%d\t%d" %(i**1, i**2, i**3, i**4))
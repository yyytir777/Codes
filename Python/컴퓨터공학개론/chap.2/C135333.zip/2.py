#2번 문제, C135333, 임원재

num1 = int(input("첫번째 정수: "))
num2 = int(input("두번째 정수: "))

print(num1 + num2)
print(num1 - num2)
print(num1 * num2)
print(((num1 + num2) / 2))
print(max(num1, num2))
print(min(num1, num2))
#1번문제, C135333, 임원재

v = int(2)
g = int(10)
t = float(9.81)
s = (v * t) + ((1/2) * g * t ** 2)
print(s)
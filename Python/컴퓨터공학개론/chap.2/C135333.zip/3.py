#3번 문제, C135333, 임원재

inch = float(input("인치="))
print(inch, "인치는", inch * 2.54, "cm")
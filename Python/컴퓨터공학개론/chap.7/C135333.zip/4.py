#4번 문제, C135333, 임원재

string = input("문자열을 입력하시오 : ")
result = ""
for i in string:
    result = i + result

print(result)